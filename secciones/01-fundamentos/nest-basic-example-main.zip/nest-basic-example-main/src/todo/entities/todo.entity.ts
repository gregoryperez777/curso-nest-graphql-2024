export class Todo {

    id: number;

    description: string;

    done: boolean = false;

}
